#!/bin/bash

# Get the Python version
PY_VERSION=$(python -c "import sys; print('.'.join(map(str, sys.version_info[:2])))")

# Uninstall a package if it is installed
for p in bok_python cython-ssm; do
    if pip show "$p" > /dev/null 2>&1; then
        echo y | pip uninstall "$p"
    fi
done

# Install packages based on the Python version
case "$PY_VERSION" in
    "3.9")
        pip install ./bok_python/dist/bok_python-0.1.0-cp39-cp39-linux_x86_64.whl
        pip install ./bok_python/ssm/dist/cython_SSM-0.1.0-cp39-cp39-linux_x86_64.whl
        ;;
    "3.10")
        pip install ./bok_python/dist/bok_python-0.1.0-cp310-cp310-linux_x86_64.whl
        pip install ./bok_python/ssm/dist/cython_SSM-0.1.0-cp310-cp310-linux_x86_64.whl
        ;;
    "3.11")
        pip install ./bok_python/dist/bok_python-0.1.0-cp311-cp311-linux_x86_64.whl
        pip install ./bok_python/ssm/dist/cython_SSM-0.1.0-cp311-cp311-linux_x86_64.whl
        ;;
    "3.12")
        pip install ./bok_python/dist/bok_python-0.1.0-cp312-cp312-linux_x86_64.whl
        pip install ./bok_python/ssm/dist/cython_SSM-0.1.0-cp312-cp312-linux_x86_64.whl
        ;;
    *)
        echo "Python version not supported."
        exit 1
        ;;
esac

# Check and install required packages
for p in ipykernel numpy pandas seaborn matplotlib cython scipy openpyxl; do
    if ! pip show "$p" > /dev/null 2>&1; then
        pip install "$p"
    fi
done

# Check for errors and display message
if [ $? -ne 0 ]; then
    echo
    echo "Installation completed with errors. Please check the above messages."
    echo
else
    echo "All packages installed successfully."
fi
