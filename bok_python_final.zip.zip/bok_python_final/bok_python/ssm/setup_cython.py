from setuptools import setup, Extension
from Cython.Build import cythonize

import numpy

# extensions = [
#     Extension("cython_SSM", ["cython_SSM.pyx"]),
# ]

setup(
    name="cython_SSM",
    version='0.1.0',
    ext_modules=cythonize('cython_SSM.pyx'),
    package_dir={'cython_ssm': ''},
    include_dirs=[numpy.get_include()],
    zip_safe=False
)