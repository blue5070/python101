import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import scipy.stats as sp
import warnings

from ..basic.operator import array, inv, ones, rows, meanc, demeanc, zeros, diag, eye, rev, vec, chol, reshape, matrix, det, sumc, minc
from ..basic.pdf import cdfn
from ..basic.rng import rand

def order_VAR(y,pmax=None):
    '''VAR(p) 모형의 최적 시차 p 추정
    
    Args:
        y = 사용하는 VAR(p) 모형의 반응변수 벡터
        pmax = 예상하는 VAR(p)모형의 최대 시차
        
    Returns:
        p_seq = 순차적 검정으로 추정된 VAR(p) 모형의 최적 시차
        p_aic = Akaike 정보기준 (AIC)로 추정된 VAR(p) 모형의 최적 시차
        p_bic = Bayesian 정보기준 (BIC)로 추정된 VAR(p) 모형의 최적 시차
        p_hq = Hannan-Quinn 정보기준 HQIC)로 추정된 VAR(p) 모형의 최적 시차
    '''
    y = array(y)
    if y.shape[1] < 2 :
        y = y.reshape(-1,1)
        print("y 변수가 단변수 (univariate) 입니다.")
    
    T, K = y.shape
    
    if pmax == None:
        pmax = round(12*((T/100)**(1/4))) # Rule of thumb, Ng and Perron (2001)

    # For Saving
    lnSig = zeros(pmax+1,1)

    # Preparing
    Y = y[pmax:T,:] # Initial LHS
    Z = ones(T-pmax,1) # Initial Constant Term
    ZZ = Z.T @ Z
    B = inv(ZZ) @ (Z.T @ Y) # OLS Estimator
    U = Y - Z @ B # Residual
    Sig = (U.T @ U) / (T-pmax) # Initial Sigma_hat
    lnSig[0,0] = np.log(det(Sig))

    for p in np.arange(pmax):
        Z = np.hstack((Z,y[pmax-p-1:T-p-1,:]))
        ZZ = Z.T @ Z
        B = inv(ZZ) @ (Z.T @ Y)
        U = Y - Z @ B
        Sig = (U.T @ U) / (T-pmax)
        lnSig[p+1,0] = np.log(det(Sig))
    
    # Sequential Testing
    LRstat = (T-pmax)*(lnSig[0:pmax,0]-lnSig[1:pmax+1,0]) # Sequence of LR test statistics
    cv = sp.chi2.ppf(0.95,K**2)
    reject = (LRstat>cv)
    if sumc(reject) == 0: # fail to reject in all cases
        p_seq = 0
    else:
        p_seq = np.max(np.nonzero(reject))
    p_seq = p_seq+1
    
    # Information Criteria
    pones = matrix(np.arange(pmax+1))
    AIC = lnSig + (2*(K**2*pones.T + K*ones(pmax+1,1)))/(T-pmax)
    BIC = lnSig + (np.log(T-pmax)*(K**2*pones.T + K*ones(pmax+1,1)))/(T-pmax)
    HQ = lnSig + (2*np.log(np.log(T-pmax))*(K**2*pones.T + K*ones(pmax+1,1)))/(T-pmax)
    aic_val, ind_aic = minc(AIC)
    bic_val, ind_bic = minc(BIC)
    hq_val, ind_hq = minc(HQ)
    
    p_aic = ind_aic[0,0]
    p_bic = ind_bic[0,0]
    p_hq = ind_hq[0,0]
    
    print('   ')
    print(' VAR Order Selected by Sequential testing = ', p_seq)
    print(' VAR Order Selected by AIC =                ', p_aic)
    print(' VAR Order Selected by BIC =                ', p_bic)
    print(' VAR Order Selected by HQ =                 ', p_hq)
    
    return p_seq, p_aic, p_bic, p_hq


def OLS_ARp(y,p,printi=None,H=None):
    ''' AR(p) 모형에 대한 OLS 추정 결과
    
    Args:
        y : 추정하고자하는 변수, T by 1 벡터
        p : 추정하는 모형의 시차
        printi : 추정 결과 출력 여부, 입력하지 않은 경우 None
        H : 최대 예측 시차, 입력하지 않을 경우 None
        
    Returns:
        phi_hat : OLS 계수 추정량, p by 1 벡터
        Omega_hat : OLS 분산 추정량, 1 by 1 벡터
        F : 동반행렬 (Companion Form) 형태의 계수 추정량
        Y0 : 추정에 사용된 반응변수, T-p by 1 벡터
        y_lag : 추정에 사용된 설명변수, T-p by p 벡터
        Y_predm : 예측된 값, H by 1 벡터
        
    * 절편항을 고려하지 않기 위해 y에 대해 자동으로 demeaning 과정이 들어감.
    ** 이후 예측 시, demeaning과정에서 제거된 mean을 다시 더해줌.
    '''
    y = array(y)
    if y.shape[1] < 2 :
        y = y.reshape(-1,1)
    else:
        print("입력하는 y 변수는 단변수 (univariate)이어야 합니다.")
    
    # 1. 반응변수 (LHS variable) 지정 및 demeaning
    Y_ = meanc(y)
    Y = demeanc(y)
    T1 = rows(Y)
    
    Y0 = Y[p:,:]
    T = rows(Y0)

    # 2. 절편을 포함한 설명변수 (RHS variable) 지정
    y_lag = zeros(T,p)
    for j in np.arange(p):
        y_lag[:,j] = Y[p-1-j:T1-j-1,:].reshape(1,-1)

    # 3. OLS estimator    
    XX = y_lag.T @ y_lag
    phi_hat = inv(XX) @ (y_lag.T @ Y0)

    # 4. Omega_hat
    y_hat = y_lag @ phi_hat
    u_hat = Y0 - y_hat
    sig2_hat = (u_hat.T @ u_hat) / (T-p)
    
    varbhat = diag(ones(p,1)*sig2_hat)*inv(XX)  # k by k, variance of bhat
    stde = np.sqrt(diag(varbhat)).reshape(-1,1) # k by 1, standard error
    b0 = zeros(p,1)  # null hypothesis
    t_val = np.divide((phi_hat - b0), stde) # k by 1, t values
    p_val = 2*(1-cdfn(np.abs(t_val))) # k by 1, t values
    
    # 5. Companion Form
    if p > 1:
        F1 = phi_hat.T 
        F2 = np.hstack((eye(p-1), zeros(p-1,1)))
        F = np.vstack((F1, F2))  # p by p
    elif p==1:
        F = phi_hat.T
       
    # 6. Prediction
    if H is None:
        Y_predm = None
    else:
        Y_predm = zeros(H,1)
        Y_Lag = rev(Y[-p:,:]) # 예측에 사용될 설명변수, 최근값이 위로 오도록 역순하기
        FF = F
        for h in range(0, H):
            Y_h = FF @ Y_Lag
            y_h = Y_h[0,0]
            Y_predm[h,:] = y_h
            Y_Lag = np.vstack((y_h, Y_Lag[0:p-1,:]))
                # Y(t-1)을 1기-얘측치로 대체
                # 대신 Y(t-P)는 제외하기
            FF = FF @ F
            
        Y_predm = Y_predm + ones(H,1)*Y_
    
    # Make Result Table
    if printi is None:
        printi = 0
    else:
        printi = 1
    
    if printi > 0:
        index = [f'AR_L{i+1}' for i in range(p)]
        cols = ["Coefficients", "S.E.", "t-value", "p-value"]
        data = np.hstack((phi_hat, stde, t_val, p_val))

        result = pd.DataFrame(np.around(data,4), index=index, columns=cols)
        print(result)
        print("==================================================================")
        
        if H is None:
            index1 = ["H = None"]
        else:
            index1 = [f'H={h+1}' for h in range(H)]
        
        cols1 = ["Predicted Value for H = " + str(H) + ' is']
        if H is None:
            data1 = []
        else:
            data1 = np.around(Y_predm,4)
            
        result1 = pd.DataFrame(data1, index=index1, columns=cols1)
        print(result1)
    
    # Plotting
    Y0 = Y0 + ones(rows(Y0),1) * Y_
    y_hat = y_hat + ones(rows(y_hat),1) * Y_
    # u_hat = u_hat + ones(rows(u_hat),1) * Y_
    
    ymax = np.concatenate((Y0,y_hat)).max()
    ymin = np.concatenate((Y0,y_hat)).min()
    umax = max(u_hat)
    umin = min(u_hat)
    if ymin > 0:
        weight = 0.9
    else:
        weight = 1.1
    if ymin < 1:
        weight = -0.5
    
    fig, ax = plt.subplots(figsize=[10,5])
    twin1 = ax.twinx()
    
    ax.plot(np.arange(1,rows(Y0)+1), Y0, '-k', np.arange(1,rows(y_hat)+1), y_hat, '-b', linewidth=1.5)
    twin1.plot(np.arange(1,rows(u_hat)+1), u_hat, '--r', linewidth=1.5, alpha = 0.8)
    
    if weight > 0:
        ran = (ymin*weight, ymax*1.1)
    else:
        ran = (ymin+weight, ymax*1.1)
    
    ax.set(xlim=(1,rows(Y0)), ylim=ran)
    twin1.set(ylim=(umin*1.1, umax*1.1))
    plt.grid(True)
    plt.title("Plot of Data, Fitted Value and Residual")
    ax.legend(['Data', 'Fitted'],loc='upper left')
    twin1.legend(['Residual'], loc='upper right')

    fig.tight_layout
    plt.show()
    
    if H is not None:
        Y_H = np.vstack((Y0, Y_predm))
        yhmax = np.max(Y_H)
        yhmin = np.min(Y_H)
        if yhmin > 0:
            weight1 = 0.9
        else:
            weight1 = 1.1
        if yhmin < 1:
            weight1 = -0.5
    
        plt.figure(figsize=[10,5])
        plt.plot(np.arange(1,rows(Y0)+1), Y0, '-k', linewidth=1.5)
        plt.title("Plot of Data and Predicted Value")
        plt.xlim([1,rows(Y_H)])
        if weight1 > 0:
            plt.ylim([yhmin*weight1, yhmax*1.1])
        else:
            plt.ylim([yhmin+weight1, yhmax*1.1])
        plt.grid(True)
        
        plt.plot(np.arange(rows(Y0)+1,rows(Y_H)+1), Y_predm, '--r', linewidth=1.5)

        plt.legend(['Data', 'Predicted'])
        plt.show()
    
    return phi_hat, sig2_hat, F, Y0, y_lag, Y_predm


def OLS_VAR(y, P=None, H=None):
    '''축약형 VAR(p) 모형 추정
    
    Args:
        y = 사용하는 VAR(p) 모형의 반응변수 행렬
        P = VAR(p) 모형의 최적 시차 (default = None)
        H = 최대 예측 시차 (default = None)
        
    Returns:
        phi_hat = 축약형 VAR(p) 모형의 계수 행렬 추정량
        Omega_hat = 축약형 VAR(p) 모형의 분산-공분산 행렬 추정량
        F = 축약형 VAR(p) 모형의 동반행렬 (Companion Matrix) 형태의 계수 행렬 추정량
        U_hat = 축약형 VAR(p) 모형의 잔차
        Y0 = 추정에 사용된 반응변수 행렬
        Y_lag = 추정에 사용된 설명변수 행렬
        Y_predm = 예측된 값
        P = 사용된 시차 (None이면 추정된 BIC값, None이 아니면 입력된 값)
    '''
    y = array(y)
    if y.shape[1] < 2 :
        y = y.reshape(-1,1)
        print("y 변수가 단변수 (univariate) 입니다.")
        
    if P == None:
        P_seq, P_aic, P_bic, P_hq = order_VAR(y)
        P = P_bic
    else:
        P = P
    
    Y_ = meanc(y) # 변수별 평균
    Y = demeanc(y) # 평균제거하기
    T,K = Y.shape # 표본크기, 변수의 수

    Y0 = Y[P:,:] # 종속변수 T-P by K
    
    Y_lag = zeros(T-P, P*K) # 설명변수를 저장할 방
    for j in np.arange(P):
        Y_lag[:, j*K:(j+1)*K] = Y[P-1-j:T-1-j,:]

    Y_lag2 = Y_lag.T @ Y_lag
    phi_hat = inv(Y_lag2) @ (Y_lag.T @ Y0) # P*K by K
 
    if P > 1:
       F1 = phi_hat.T 
       F2 = np.hstack((eye((P-1)*K), zeros(K*(P-1),K)))
       F = np.vstack((F1, F2))  # p*k by p*k
    elif P==1:
       F = phi_hat.T

    T0 = rows(Y0)

    # Omega_hat 
    U_hat = Y0 - Y_lag @ phi_hat # T-p by k 
    Omega_hat = U_hat.T @ U_hat/(T0-P*K)  # k by k

    # 예측
    if H is None:
        Y_predm = None
    else:
        Y_predm = zeros(H, K)
        Y_Lag = rev(Y[-P:,:]) # 예측에 사용될 설명변수, 최근값이 위로 오도록 역순하기
        FF = F
        for h in range(0, H):
            Vec_Y_Lag = vec(Y_Lag.T)
            Y_h = FF*Vec_Y_Lag
            y_h = Y_h[0:K, 0] 
            Y_predm[h, :] = y_h.T
            Y_Lag = np.vstack((y_h.T, Y_Lag[0:P-1, :])) 
                 # Y(t-1)을 1기-얘측치로 대체
                 # 대신 Y(t-P)는 제외하기 
            FF = FF*F

        Y_predm = Y_predm + np.kron(ones(H, 1), Y_.T)  # 표본평균 보정(+)해주기

    return phi_hat, Omega_hat, F, U_hat, Y0, Y_lag, Y_predm, P


def B0invSolve(phi_hat, Omega_hat, restrict):
    '''단기 또는 장기 제약을 통한 구조 VAR(p) 모형 식별
    
    Args:
        phi_hat : 추정된 축약형 VAR(p) 모형의 계수 행렬 (장기제약 시 사용됨)
        Omega_hat : 추정된 축약형 VAR(p) 모형의 분산-공분산 행렬 (장,단기 제약 모두에 사용됨)
        restrict : 장,단기 제약에 대한 옵션
                    'short' 또는 'long'으로 입력할 것, string
    
    Returns:
        B0inv : 구조형 VAR(p) 모형의 식별에 사용되는 B0의 역행렬 (B0inv)
    '''
    # 1. Short-run Restriction
    if restrict == 'short':
        B0inv = chol(Omega_hat).T
    # 2. Long-run Restriction
    elif restrict == 'long':
        A = phi_hat.T
        K,n = A.shape
        p = n/K
        p = int(p)
        A1 = eye(K)
        
        for j in range(p):
            A1 = A1 - A[:,j*K:(j+1)*K]
            
        Phi = inv(A1) # Phi(1)
        temp = Phi @ Omega_hat @ Phi.T
        temp = 0.5*(temp+temp.T)
        Lbar = chol(temp).T
        # Lbar[1,1] = -Lbar[1,1].copy(); for Blanchard and Quah replication
        B0inv = A1 @ Lbar
    else:
        print("경고: 올비르지 못한 졔약조건(restriction)입니다.")
        print("restrict 변수는 단기제약의 경우 'short', 장기제약의 경우 'long', 일반화된 충격반응함수의 경우 'general' 이어야 합니다.")
        
    return B0inv


def irf_estimate(F,p,H,B0inv):
    '''충격반응함수 추정
    
    Args:
        F : VAR(p) 모형의 동반행렬 (Companion Form) 형태의 계수 행렬 추정치
        p : VAR(p) 모형의 최적 시차
        H : 충격반응함수 도출 시 사용되는 예측 시차
        B0inv : 식별제약에 따른 B0 역행렬
        
    Returns:
        Theta : 추정된 충격반응함수, H+1 by K^2
    '''
    K = rows(B0inv)
    FF = eye(p*K)
    vecB0inv = vec(B0inv.T)
    Theta = vecB0inv.copy() # at h=0, (K^2 * 1) is the response
    for h in np.arange(H):
        FF = F @ FF
        theta = FF[0:K,0:K] @ B0inv
        theta = vec(theta.T)
        Theta = np.hstack((Theta, theta))
        
    return Theta


def randper(y):
    ''' 행렬 원소의 위치 랜덤하게 바꾸기
    
    Args:
        y : 원소의 위치를 바꾸고자하는 변수 (행렬 또는 벡터 모두 가능)
        
    Returns:
        z : 원소의 위치가 바뀐 변수
    '''
    n = rows(y)
    z = y.copy()

    k = n-1
    while k > 1:
        i = np.ceil(rand(1,1)*k) # matrix
        i = i[0,0]
        i = int(i)
        zi = z[i,:].copy() # interchange values
        zk = z[k,:].copy() # change zi to zk
        z[i,:] = zk
        z[k,:] = zi
        k = k-1

    return z


def SVAR(y,H,restrict,qt=None,p=None):
    '''VAR 충격반응함수 및 부트스래핑 (Bootstrapping)을 통한 충격반응함수의 신뢰구간 도출
    
    Args:
        y : VAR(p) 모형에 사용되는 반응변수 행렬
        H : 충격반응함수 도출 시 고려하는 최대 예측시차
        restrict: 사용하고자하는 식별 방법 ('short' = 단기제약, 'long' = 장기제약)
        qt : 충격반응함수의 신뢰구간 (confidence interval)
            입력하지 않을 시 default = 90 (90% 신뢰구간)
        p : VAR(p) 모형의 최적 시차 (default = None)
    
    Returns:
        Theta : 추정된 VAR(p) 모형의 충격반응함수
        CILv : 충격반응함수 신뢰구간의 하한
        CIHv : 충격반응함수 신뢰구간의 상한
        cumTheta : 추정된 VAR(p) 모형의 누적된 충격반응함수
        cumCILv : 누적된 충격반응함수 신뢰구간의 하한
        cumCIHv : 누적된 충격반응함수 신뢰구간의 상한
        ForVar : 예측 오차 분산 분해 결과 (K by (H+1))
            - K개의 행은 각 충격이 k번째 변수에 기여하는 정도
            - (H+1)개의 열은 각 예측 시차
        HDm : 각 반응변수에 대한 역사적 분해 결과
    
    Steps:
        <1 단계>: 축약형 VAR(p) 모형 추정 (demean 사용)
        <2 단계>: 단기, 또는 장기 제약으로 B0inv 도출
        <3 단계>: 잔차를 섞어 새로운 잔차를 랜덤 샘플링
        <4 단계>: 부트스트랩 샘플을 얻은 후 축약형 VAR(p) 모형을 다시 추정
        <5 단계>: 충격반응함수를 추정
        <6 단계>: <3 단계>부터 <5단계>까지 반복 한 이후 신뢰구간을 도출
    '''
    y = array(y)
    if y.shape[1] < 2 :
        y = y.reshape(-1,1)
        print("y 변수가 단변수 (univariate) 입니다.")
    
    T,K = y.shape
    
    if restrict == 'general':
        Theta, CILv, CIHv, cumTheta, cumCILv, cumCIHv = VAR_GenIRF(y,H,qt,p)
    else:
        # <Step 1>: Estimate Reduced-form VAR (with demeaning)
        phi_hat, Omega_hat, F, U_hat, Y0, Y_lag, Y_predm, phat = OLS_VAR(y,p)
        psave = p
        p = phat

        # <Step 2>: Obtain B0inv by short-run restriction
        B0inv = B0invSolve(phi_hat, Omega_hat, restrict)

        # Save the initial IRF
        Theta = irf_estimate(F,p,H,B0inv)
        cumTheta = zeros(K**2,H+1)
        for c in range(K**2):
            cumtemp = np.cumsum(Theta[c,:])
            cumTheta[c,:] = cumtemp

        # CI (Bootstrapping)
        n = 2000

        IRFm = zeros(n,K**2*(H+1))
        cumIRFm = zeros(n,K**2*(H+1))

        for iter in range(n):
            # <Step 3>: Obtain a new set of errors
            indu = matrix(range(T-p)) # 0 from 93
            indu = indu.T
            indu = randper(indu)
            indu = indu.astype(int) # make matrix as an integer

            ustar = U_hat[indu,:]

            ystar = zeros(T,K)
            ind_ystar = np.fix(rand(1,1)*(T-p+1))+1
            ind_ystar = ind_ystar[0,0]
            ind_ystar = ind_ystar.astype(int)
            ystar[0:p-1,:] = y[ind_ystar:ind_ystar+p-1,:]

            # <Step 4>: Obtain the Bootstrap Sample and estimate again
            for it in range(p,T):
                ystar[it,:] = ustar[it-p,:]
                for jt in range(p):
                    ystar[it,:] = ystar[it,:] + ystar[it-jt-1,:] @ phi_hat[jt*K:(jt+1)*K,:]

            phi_star, Omega_star, F_star, u_star, Y0_star, Y_lag_star, Y_predm, phat_star = OLS_VAR(ystar, p)

            B0inv_star = B0invSolve(phi_star, Omega_star, restrict)

            # <Step 5>: Compute the Impulse Response Function
            IRFboot = irf_estimate(F_star, p, H, B0inv_star)
            cumIRFboot = zeros(K**2,H+1)
            for c in range(K**2):
                cumIRFboot[c,:] = np.cumsum(IRFboot[c,:])

            IRFm[iter,:] = vec(IRFboot.T).T
            cumIRFm[iter,:] = vec(cumIRFboot.T).T

        # <Step 6>: Obtain Quantiles
        if qt is None:
            CIlow = np.quantile(np.array(IRFm), 0.05, axis=0) # must be an option (default = 5%)
            CIhigh = np.quantile(np.array(IRFm), 0.95, axis=0) # must be an option (default = 95%)
            cumCIlow = np.quantile(np.array(cumIRFm), 0.05, axis=0) # must be an option (default = 5%)
            cumCIhigh = np.quantile(np.array(cumIRFm), 0.95, axis=0) # must be an option (default = 95%)
        else:
            qtlow = ((100-qt)/2)*0.01
            qthigh = (100 - qtlow)*0.01
            CIlow = np.quantile(np.array(IRFm), qtlow, axis=0)
            CIhigh = np.quantile(np.array(IRFm), qthigh, axis=0)
            cumCIlow = np.quantile(np.array(cumIRFm), qtlow, axis=0)
            cumCIhigh = np.quantile(np.array(cumIRFm), qthigh, axis=0)

        CIlow_mat = matrix(CIlow)
        CIhigh_mat = matrix(CIhigh)
        cumCIlow_mat = matrix(cumCIlow)
        cumCIhigh_mat = matrix(cumCIhigh)

        CILv = reshape(CIlow_mat.T, H+1, K**2).T
        CIHv = reshape(CIhigh_mat.T, H+1, K**2).T
        cumCILv = reshape(cumCIlow_mat.T,H+1,K**2).T
        cumCIHv = reshape(cumCIhigh_mat.T,H+1,K**2).T
        
        if psave == None:
            print(" ")
            print("BIC로 추정한 VAR 최적 시차 = ", phat)
        else:
            print(" ")
            print("사용자가 입력한 VAR 최적 시차 = ", phat)

    '''
    Plotting Results
    '''
    name = []
    for idx in range(1,K+1):
        for idx2 in range(1,K+1):
            warnings.filterwarnings("ignore")
            name1 = r"$e_{idx2} \Rightarrow y_{idx}$"
            name.append(name1)

    name = np.array(name)
    time = np.matrix(np.arange(0,H+1))

    plt.figure(figsize=(K*3.3, K*3.3))  
    for i in range(1,K**2+1):
        plt.subplot(K,K,i)
        plt.plot(time.T, Theta[i-1,:].T, '-k', time.T, CIHv[i-1,:].T, '-.b', time.T, CILv[i-1,:].T, '-.b', time.T, zeros(H+1,1), '-r')
        plt.xlim([0,H+1])
        plt.title(name[i-1])
    
    if restrict == 'general':
        plt.legend(['GenIRF', 'Bootstrap'])
    else:
        plt.legend(['IRF', 'Bootstrap'])
        
    plt.show()
    
    plt.figure(figsize=(K*3.3, K*3.3))  
    for i in range(1,K**2+1):
        plt.subplot(K,K,i)
        plt.plot(time.T, cumTheta[i-1,:].T, '-k', time.T, cumCIHv[i-1,:].T, '-.b', time.T, cumCILv[i-1,:].T, '-.b', time.T, zeros(H+1,1), '-r')
        plt.xlim([0,H+1])
        plt.title(name[i-1])
    
    plt.legend(['cumIRF', 'Bootstrap'])
    plt.show()
    
    if restrict == 'general':
        ForVar = []
        HDm = []
    else:
        ForVar = VarDecomp(phi_hat,Omega_hat,F,restrict,p,H)
        HDm = HistDecomp(y,p,phi_hat,Omega_hat,F,U_hat,restrict)
    
    return Theta, CILv, CIHv, cumTheta, cumCILv, cumCIHv, ForVar, HDm


def VAR_GenIRF(y,H,qt=None,p=None):
    '''VAR 일반화된 충격반응함수 및 부트스트래핑을 통한 신뢰구간 도출
    
    Args:
        y : VAR(p) 모형에 사용되는 반응변수
        H : 충격반응함수 도출 시 고려하는 최대 예측시차
        qt : 충격반응함수의 신뢰구간 (confidence interval)
            입력하지 않을 시 default = 90 (90% 신뢰구간)
        p : VAR(p) 모형의 최적 시차
            입력하지 않을 시 default = None (자동 추정)
    
    Returns:
        Theta : VAR 모형의 충격반응함수
        CILv : 충격반응함수 신뢰구간의 하한
        CIHv : 충격반응함수 신뢰구간의 상한
        cumTheta : 추정된 VAR(p) 모형의 누적된 충격반응함수
        cumCILv : 누적된 충격반응함수 신뢰구간의 하한
        cumCIHv : 누적된 충격반응함수 신뢰구간의 상한
    
    Steps:
        <1 단계>: 축약형 VAR(p) 모형 추정 (demean 사용)
        <2 단계>: Omega_hat./sqrt(sigma_{ii})을 통한 C 도출
        <3 단계>: 잔차를 섞어 새로운 잔차를 랜덤 샘플링
        <4 단계>: 부트스트랩 샘플을 얻은 후 축약형 VAR(p) 모형을 다시 추정
        <5 단계>: 충격반응함수를 추정
        <6 단계>: <3 단계>부터 <5단계>까지 반복 한 이후 신뢰구간을 도출
    '''
    y = array(y)
    if y.shape[1] < 2 :
        y = y.reshape(-1,1)
        print("y 변수가 단변수 (univariate) 입니다.")
    
    T,K = y.shape

    # <Step 1>: Estimate Reduced-form VAR (with demeaning)
    phi_hat, Omega_hat, F, U_hat, Y0, Y_lag, Y_predm, phat = OLS_VAR(y,p)
    psave = p
    p = phat

    # <Step 2>: Obtain B0inv by short-run restriction
    C = Omega_hat/np.kron(ones(rows(Omega_hat),1),np.sqrt(np.diag(Omega_hat)).T) # 1 standard dev shock

    # Save the initial IRF
    Theta = irf_estimate(F,p,H,C)
    cumTheta = zeros(K**2,H+1)
    for c in range(K**2):
        cumtemp = np.cumsum(Theta[c,:])
        cumTheta[c,:] = cumtemp

    # CI (Bootstrapping)
    n = 2000

    IRFm = zeros(n,K**2*(H+1))
    cumIRFm = zeros(n,K**2*(H+1))

    for iter in range(n):
        # <Step 3>: Obtain a new set of errors
        indu = matrix(range(T-p)) # 0 from 93
        indu = indu.T
        indu = randper(indu)
        indu = indu.astype(int) # make matrix as an integer
    
        ustar = U_hat[indu,:]

        ystar = zeros(T,K)
        ind_ystar = np.fix(rand(1,1)*(T-p+1))+1
        ind_ystar = ind_ystar[0,0]
        ind_ystar = ind_ystar.astype(int)
        ystar[0:p-1,:] = y[ind_ystar:ind_ystar+p-1,:]

        # <Step 4>: Obtain the Bootstrap Sample and estimate again
        for it in range(p,T):
            ystar[it,:] = ustar[it-p,:]
            for jt in range(p):
                ystar[it,:] = ystar[it,:] + ystar[it-jt-1,:] @ phi_hat[jt*K:(jt+1)*K,:]
        
        phi_star, Omega_star, F_star, u_star, Y0_star, Y_lag_star, Y_predm, phat_star = OLS_VAR(ystar, p)

        C_star = Omega_star/np.kron(ones(rows(Omega_star),1),np.sqrt(np.diag(Omega_star)).T)

        # <Step 5>: Compute the Impulse Response Function
        IRFboot = irf_estimate(F_star, p, H, C_star)
        cumIRFboot = zeros(K**2,H+1)
        for c in range(K**2):
            cumIRFboot[c,:] = np.cumsum(IRFboot[c,:])
        
        IRFm[iter,:] = vec(IRFboot.T).T
        cumIRFm[iter,:] = vec(cumIRFboot.T).T

    # <Step 6>: Obtain Quantiles
    if qt is None:
        CIlow = np.quantile(np.array(IRFm), 0.05, axis=0) # must be an option (default = 5%)
        CIhigh = np.quantile(np.array(IRFm), 0.95, axis=0) # must be an option (default = 95%)
        cumCIlow = np.quantile(np.array(cumIRFm), 0.05, axis=0) # must be an option (default = 5%)
        cumCIhigh = np.quantile(np.array(cumIRFm), 0.95, axis=0) # must be an option (default = 95%)
    else:
        qtlow = ((100-qt)/2)*0.01
        qthigh = (100 - qtlow)*0.01
        CIlow = np.quantile(np.array(IRFm), qtlow, axis=0)
        CIhigh = np.quantile(np.array(IRFm), qthigh, axis=0)
        cumCIlow = np.quantile(np.array(cumIRFm), qtlow, axis=0)
        cumCIhigh = np.quantile(np.array(cumIRFm), qthigh, axis=0)
    
    CIlow_mat = matrix(CIlow)
    CIhigh_mat = matrix(CIhigh)
    cumCIlow_mat = matrix(cumCIlow)
    cumCIhigh_mat = matrix(cumCIhigh)

    CILv = reshape(CIlow_mat.T, H+1, K**2).T
    CIHv = reshape(CIhigh_mat.T, H+1, K**2).T
    cumCILv = reshape(cumCIlow_mat.T,H+1,K**2).T
    cumCIHv = reshape(cumCIhigh_mat.T,H+1,K**2).T
    
    if psave == None:
        print(" ")
        print("BIC로 추정한 VAR 최적 시차 = ", phat)
    else:
        print(" ")
        print("사용자가 입력한 VAR 최적 시차 = ", phat)
    
    return Theta, CILv, CIHv, cumTheta, cumCILv, cumCIHv


def VarDecomp(phi_hat,Omega_hat,F,restrict,p,H):
    '''VAR(p) 모형의 예측오차 분산분해 결과 도출
    
    Args:
        phi_hat = 축약형 VAR(p) 모형의 계수 행렬 추정량
        Omega_hat = 축약형 VAR(p) 모형의 분산-공분산 행렬 추정량
        F : VAR(p) 모형의 동반행렬 (companion matrix) 형태의 계수 행렬 추정치
        restrict: 사용하고자하는 식별 방법 (short=단기제약, long=장기제약)
        p : VAR(p) 모형의 최적 시차
        H : 예측 오차 도출 시 사용되는 예측 시차
        
    Returns:
        ForVar : 예측 오차 분산 분해 결과 (K by (H+1))
            - K개의 행은 각 충격이 k번째 변수에 기여하는 정도
            - (H+1)개의 열은 각 예측 시차
    '''
    B0inv = B0invSolve(phi_hat, Omega_hat, restrict)

    K = rows(B0inv)
    FF = eye(p*K)

    ForVar = zeros(K**2,H+1)

    Theta0 = B0inv
    varmat = np.power(Theta0,2)
    Rvarmat = varmat / np.kron(ones(K,1), varmat.sum(axis=1)).T
    ForVar[:,0] = vec(Rvarmat.T).reshape(1,-1)

    for h in range(H):
        FF = F @ FF
        Theta = FF[0:K,0:K] @ B0inv
        varmat = varmat + np.power(Theta,2)
        Rvarmat = varmat / np.kron(ones(K,1), varmat.sum(axis=1)).T
        ForVar[:,h+1] = vec(Rvarmat.T).reshape(1,-1)
    
    name = []
    for k in range(K):
        name1 = f"e_{k}"
        name.append(name1)
    
    for k in range(1,K+1):
        combined = pd.DataFrame(ForVar[(k-1)*K:k*K,:].T)
        df_decomp = pd.DataFrame(combined)

        variindex = list(range(0, H+1, 1))
        palette = sns.color_palette("muted", df_decomp.shape[1])

        df_decomp.index = df_decomp.index + 1

        plt.figure(figsize=(20, 5))
    
        bottom = np.zeros(len(df_decomp))
        for i, color in zip(range(df_decomp.shape[1]), palette):
            plt.bar(variindex, df_decomp.iloc[:, i], bottom=bottom, color=color)
            plt.xlim([-1,H+1])
            plt.ylim([0,1])
            plt.title(f'Forecast Error Variance for Var {k}')
            bottom += df_decomp.iloc[:, i]
        
        plt.legend(name)

    plt.grid()
    plt.show()
    
    return ForVar


def HistDecomp(y,p,phi_hat,Omega_hat,F,U_hat,restrict):
    '''역사적 분해 (Historical Decomposition)
    
    Args:
        y : VAR(p) 모형을 구성하는 반응변수
        p : VAR(p) 모형의 최적 시차
        phi_hat : 축약형 VAR(p) 모형의 계수 행렬 추정량
        Omega_hat : 축약형 VAR(p) 모형의 분산-공분산 행렬 추정량
        F : VAR(p) 모형의 동반행렬 (companion matrix) 형태의 계수 행렬 추정치
        restrict: 사용하고자하는 식별 방법 (short=단기제약, long=장기제약)
        
    Returns:
        HDm : 각 반응변수에 대한 역사적 분해 결과
    '''
    y = array(y)
    if y.shape[1] is None:
        y = y.reshape(-1,1)
        print("y 변수가 단변수 (univariate) 입니다.")
    T,K = y.shape
    
    # <Step 1>: Estimate the reduced-form VAR
    # 함수 밖에서 이루어짐.
    
    # <Step 2>: Identify the structural-form VAR
    B0inv = B0invSolve(phi_hat,Omega_hat,restrict)

    # <Step 3>: Obtain the structural form residual
    e_hat = U_hat @ inv(B0inv)

    # <Step 4>: Obtain the Impulse response functions
    Theta = irf_estimate(F,p,T-p-1,B0inv)

    # <Step 5>: Obtain the weights for the effect of a given shock
    yhatm = zeros(K,T-p-1,K) # shock, T, variable

    for ind_var in range(K):
        yhats = zeros(T-p-1,K)
        for t in range(T-p-1):
            for ind_shock in range(K):
                dot_temp = Theta[ind_var+ind_shock*K,:t+1] @ e_hat[t::-1,ind_shock]
                yhats[t,ind_shock] = dot_temp

        temp = zeros(1,T-p-1)
        for ind_shock in range(K):
            temp = np.vstack((temp,yhats[:,ind_shock].T))

        temp = temp[1:,:]
        yhatm[:,ind_var,:] = temp

    T1,K = U_hat.shape
    
    # Plotting
    name = []
    for k in range(K):
        name1 = f"e_{k}"
        name.append(name1)

    for ind_var in range(0,K):
        HD = yhatm[:,ind_var,:]
        df_decomp = pd.DataFrame(HD.T)
        variindex = list(range(1,T1,1))
        palette = sns.color_palette("muted", df_decomp.shape[1])
        df_decomp.index = df_decomp.index + 1
        plt.figure(figsize=(20, 5))

        bottom_pos = np.zeros(T1-1)
        bottom_neg = np.zeros(T1-1)

        for i, color in zip(range(df_decomp.shape[1]), palette):

            values = df_decomp.iloc[:,i]
            bottom = np.where(values >= 0, bottom_pos, bottom_neg)

            plt.bar(variindex, df_decomp.iloc[:, i], bottom=bottom, color=color)
            plt.xlim([-1,T1+1])
            plt.title(f'Historical Decomposition for Var {ind_var+1}')

            bottom_pos = np.where(values >= 0, bottom_pos + values, bottom_pos)
            bottom_neg = np.where(values < 0, bottom_neg + values, bottom_neg)

        plt.legend(name)

    plt.grid()
    plt.show()
    
    HDm = yhatm
    
    return HDm


def Long_Var(y,window=None):
    '''장기 분산 추정
    
    Args:
        y : 추정하고자하는 변수(들), 단변수 또는 다변수 모두 가능
        window : 사용하고자하는 윈도우 종류
            - 1 = Bartlett Window를 사용 (추정된 장기 분산이 Newey-West 추정량이라고도 부름)
            - 2 = AR(1) 과정을 통해 근사한 밴드 넓이 파라미터 (bandwidth parameter)를 사용한 Quadratic Window (default)
              reference: Andrews (1991)
    
    Returns:
        Jhat : 장기 분산 추정치
    '''
    y = array(y)
    if y.shape[1] < 2 :
        y = y.reshape(-1,1)
    
    vhat_ = meanc(y)
    vhat = demeanc(y)

    T, K = vhat.shape

    # 1. Get estimator of autocovariance function
    Gamma = zeros(T*K,K)

    for j in range(T):
        gamma = (1/T) * vhat[j:T,:].T @ vhat[0:T-j,:]
        Gamma[K*j:K*(j+1),0:K] = gamma
    
    # 2. Select the bandwidth parameter (by AR(1) approximation)
    rho = zeros(K,1)
    sigma = zeros(K,1)

    # 2-(1). AR(1) regression
    for i in range(K):
        v = vhat[:,i].reshape(-1,1)
        v0 = v[1:T,:]
        v_lag = v[0:T-1,:]
        v_lag2 = v_lag.T @ v_lag
    
        r = inv(v_lag2) @ (v_lag.T @ v0)
        rho[i,:] = r
    
        e_hat = v0 - v_lag @ r
        sigma[i,:] = (e_hat.T @ e_hat) / T
    
    # 2-(2) AR(1) approximation
    denom1 = 0
    numer1 = 0
    for ind in range(K):
        numer1 = numer1 + 4*(rho[ind,:]**2)*(sigma[ind,:]**2) / ((1-rho[ind,:])**6 * (1+rho[ind,:])**2)
        denom1 = denom1 + (sigma[ind,:]**2) / ((1-rho[ind,:])**4)
    
    alpha1 = numer1 / denom1
    
    denom2 = 0
    numer2 = 0

    for ind in range(K):
        numer2 = numer2 + 4*(rho[ind,:]**2)*(sigma[ind,:]**2) / ((1-rho[ind,:])**8)
        denom2 = denom2 + (sigma[ind,:]**2) / ((1-rho[ind,:])**4)

    alpha2 = numer2 / denom2

    # 2-(3) Bandwidth parameter
    if window == 1: # Bartlett Kernel (Newey-West)
        temp = alpha1*T
        s_T1 = 1.1447 * temp**(1/3)
        s_T = np.floor(s_T1)
        s_T = int(s_T)
    else: # Quadratic Kernel (Andrews 1991)
        temp = alpha2*T
        s_T = 1.3221 * temp**(1/5)
    
    # 3. Applying Window
    J = Gamma[0:K,:] # Gamma(0)

    if window == 1:
        for j in np.arange(1,s_T+1):
            weight = 1 - np.abs(j/s_T1)
            J = J + weight*Gamma[j*K:j*K+K,:]
            
        for j in np.arange(1,s_T+1):
            weight = 1 - np.abs(j/s_T1)
            J = J + weight*Gamma[j*K:j*K+K,:].T
        
    else:
        for j in np.arange(1,T-1):
            d = (6*np.pi*(j/s_T)) / 5
            weight = (25/(12*(np.pi**2)*(j/s_T)**2)) * ((np.sin(d)/d) - np.cos(d))
            J = J + weight*Gamma[j*K:j*K+K,:]
        
        for j in np.arange(1,T-1):
            d = (6*np.pi*(-j/s_T)) / 5
            weight = (25/(12*np.pi**2*(j/s_T)**2)) * ((np.sin(d)/d) - np.cos(d))
            J = J + weight*Gamma[j*K:j*K+K,:].T
        
    Jhat = J * (T/(T-K))
    
    return Jhat