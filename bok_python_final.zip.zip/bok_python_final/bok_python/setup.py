from setuptools import setup, find_packages, Extension
from Cython.Build import cythonize

import numpy

# Define extensions that need compiling
extensions = [
    Extension('.ssm.cython_SSM', ['./ssm/cython_SSM.pyx'])
]

# Use cythonize on the defined extensions
cython_extensions = cythonize(extensions)

setup(
    name='bok_python',
    version='0.1.0',
    description='BOK Python Package for a Time Series Analysis',
    long_description=open('README.md', 'rt', encoding='UTF8').read(),
    long_description_content_type='text/markdown',
    include_dirs=[numpy.get_include()],
    packages=find_packages(),
    package_dir={'bok_python': ''},
    ext_modules=cython_extensions,
    install_requires=[
        'numpy',
        'pandas',
        'cython',
        'seaborn',
        'matplotlib',
        'scipy',
        'seaborn'
    ],
    python_requires='>=3.9'
)